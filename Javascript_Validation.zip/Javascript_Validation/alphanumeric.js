function isAlphanumeric(password) {
	//var regexPattern = /(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]/g; //Regex
	var status = true;
	//Check apakah hanya ada huruf atau angka
	for(var index = 0; index < password.length; index++) {
		if(!(password.charAt(index) >= 'A' && password.charAt(index) <= 'Z' || password.charAt(index) >= 'a' && password.charAt(index) <= 'z' || password.charAt(index) >= '0' && password.charAt(index) <= '9')) {
			status = false;
			break;
		}
	}
	//Check apakah ada angka
	if(status) {
		for(var index = 0; index < password.length; index++) {
			if(password.charAt(index) >= '0' && password.charAt(index) <= '9') {
				status = true;
				break;
			}
			else {
				status = false;
			}
		}
	}
	//Check apakah ada huruf
	if(status) {
		for(var index = 0; index < password.length; index++) {
			if(password.charAt(index) >= 'A' && password.charAt(index) <= 'Z' || password.charAt(index) >= 'a' && password.charAt(index) <= 'z'){
				status = true;
				break;
			}
			else status = false;
		}
	}
	return status;
}

var password = "thisisthestrongestpasswordinthisfuckingworld";
console.log(isAlphanumeric(password)); //False;	

password = "1234567890";
console.log(isAlphanumeric(password)); //False;

password = "password123456";
console.log(isAlphanumeric(password)); //True;