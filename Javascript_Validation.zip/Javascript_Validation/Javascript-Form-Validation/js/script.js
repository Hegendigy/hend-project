//Disini kita mengambil semua elemen span yang ada di dalam form kita untuk dapat menunjukkan error
let error = document.querySelectorAll("span");

//Kita ambil elemen button submit kita
let btnSubmit = document.getElementById("btn-submit");

let validate = function(e)
{
    e.preventDefault();
    //Disini kita ambil semua elemen input yang ada
    let username = document.getElementById("usernameTxt");
    let password = document.getElementById("passwordTxt");
    let reConfPassword = document.getElementById("rePasswordTxt");
    let email = document.getElementById("emailTxt");
    let address = document.getElementById("addressTxt");
    let checkbox = document.getElementById("check-box");

    let result = true;

    if(username.value.length < 5 || username.value.length > 15)
    {
        error[0].innerHTML = "Username must be between 5 - 15 characters!";
        result = false;
        return;
    } 
    else error[0].innerHTML = "";

    if(password.value.length == 0)
    {
        error[1].innerHTML = "Password must be entered!";
        result = false;
        return;
    }
    else error[1].innerHTML = "";

    if(reConfPassword.value != password.value)
    {
        error[2].innerHTML = "Password must be the same!";
        result = false;
        return;
    }
    else error[2].innerHTML = "";

    if(!email.value.includes("@"))
    {
        error[3].innerHTML = "Email must contain '@'";
        result = false;
        return;
    }
    else error[3].innerHTML = "";

    if(email.value.indexOf("@") != email.value.lastIndexOf("@"))
    {
        error[3].innerHTML = "Email must only containt one '@'";
        result = false;
        return;
    }
    else error[3].innerHTML = "";

    if(!address.value.endsWith(" Street") && !address.value.endsWith(" street"))
    {
        error[4].innerHTML = "Address must be end with ' street'";
        result = false;
        return;
    }
    else error[4].innerHTML = "";

    if(!checkbox.checked)
    {
        error[5].innerHTML = "Terms and conditions must be agreed!";
        result = false;
        return;
    }
    else error[5].innerHTML = "";

    if(result)
    {
        username.value = "";
        password.value = "";
        reConfPassword.value = "";
        email.value = "";
        address.value = "";
        checkbox.checked = false;
        alert("Success created new account!");
    }

}

btnSubmit.addEventListener("click", e => validate(e));

